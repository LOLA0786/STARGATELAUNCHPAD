# Arabic Customer Support Prompts
1) Respond politely in Modern Standard Arabic.
